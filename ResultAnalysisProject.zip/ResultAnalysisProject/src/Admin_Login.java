import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class Admin_Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Login frame = new Admin_Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Admin_Login() {
		setTitle("Admin Login Window");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.PLAIN, 17));
		lblNewLabel.setBounds(42, 64, 46, 14);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(208, 58, 146, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(42, 117, 112, 14);
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(208, 116, 146, 20);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("LOGIN");
		btnNewButton.setBounds(254, 189, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.setBounds(59, 189, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(221, 236, 179, 14);
		contentPane.add(lblNewLabel_2);
		
		//Back Button
		btnNewButton_1.addActionListener(new ActionListener()
				{public void actionPerformed(ActionEvent ae){
		Home obj=new Home();
		obj.setVisible(true);
		Admin_Login.this.setVisible(false);
				}});
		
		//Login Window
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				String id=textField.getText();
				String password=String.valueOf(passwordField.getPassword());
				connector con=new connector();
				try{
					PreparedStatement ps=connector.con1.prepareStatement("select * from admin_info");
					ResultSet rs=ps.executeQuery();
					int i=0;
					while(rs.next())
					{
						String IDchk=rs.getString("id");
						String Passwordchk=rs.getString("password");
						if(IDchk.equals(id) && (Passwordchk.equals(password)))
						{
							i=1;
							break;
						}
					}
					
					if(i==0){
						lblNewLabel_2.setForeground(Color.red);
						lblNewLabel_2.setText("details are incorrect");
					}
					else if(i==1){
						AdminHome obj=new AdminHome();
						obj.setVisible(true);
						Admin_Login.this.setVisible(false);
					}
				}catch(Exception e)
				{}
				
			}
				});
		
		
		
		
		
		
		
		
		
	}

}
