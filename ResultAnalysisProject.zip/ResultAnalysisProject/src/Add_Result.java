import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.JButton;

public class Add_Result extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Result frame = new Add_Result();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Result() {
		setTitle("Add Result");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 430, 273);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ENTER ENROLLMENT NUMBER OF STUDENT");
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.PLAIN, 17));
		lblNewLabel.setBounds(13, 36, 457, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ENROLL");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(13, 90, 86, 14);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(180, 89, 156, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD RESULT");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton.setBounds(202, 150, 122, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton_1.setBounds(35, 150, 122, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(35, 197, 320, 14);
		contentPane.add(lblNewLabel_2);
		
		
		//BACK BUTTON
		btnNewButton_1.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				AdminHome obj=new AdminHome();
				obj.setVisible(true);
				Add_Result.this.setVisible(false);
			}
				});
		
		
		//Add Result Button
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
					connector con=new connector();
					String enroll=textField.getText();
					ShareDataEnroll data=new ShareDataEnroll();
					data.setData(enroll);
					try{
					PreparedStatement ps=connector.con1.prepareStatement("select * from student_info");
					ResultSet rs=ps.executeQuery();
					int i=0;
					while(rs.next())
					{
						if(enroll.equals(rs.getString("enroll")))
						{
							i=1;
						}
					}
					if(i==0)
					{
						lblNewLabel_2.setForeground(Color.red);
						lblNewLabel_2.setText("No Student Found for this ennrollment number");
					}
					else
					{
					
						Add_Result_0 obj=new Add_Result_0();
						obj.setVisible(true);
						Add_Result.this.setVisible(false);
					}
					
					}catch(Exception e)
					{}
					
					
					}
				});
		
		
	}

}
