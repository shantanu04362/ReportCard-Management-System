import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

public class Student_Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Login frame = new Student_Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Login() {
		setTitle("Student Login Window");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Enrollment Number");
		lblNewLabel.setBounds(42, 55, 178, 20);
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.PLAIN, 17));
		
		textField = new JTextField();
		textField.setBounds(259, 57, 135, 20);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(42, 106, 114, 14);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(textField);
		contentPane.add(lblNewLabel_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(259, 105, 135, 20);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(259, 186, 89, 23);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(233, 236, 135, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setBounds(69, 186, 89, 23);
		contentPane.add(btnBack);
		
		//Back Button
		btnBack.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Home obj=new Home();
				obj.setVisible(true);
				Student_Login.this.setVisible(false);
			}
				});
		//Login Button
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				connector con=new connector();
				try{
					String enroll=textField.getText();
					String password=String.valueOf(passwordField.getPassword());
					PreparedStatement ps=connector.con1.prepareStatement("select * from student_info");
					ResultSet rs=ps.executeQuery();
					int i=0;
					while(rs.next())
					{
						String enrollchk=rs.getString("enroll");
						String passwordchk=rs.getString("password");
						if(enrollchk.equals(enroll) && passwordchk.equals(password))
						{
							i=1;
							break;
						}
					}
					if(i==0)
					{
						lblNewLabel_2.setForeground(Color.red);
						lblNewLabel_2.setText("wrong details");
					}
					else{
						ShareDataEnrollStudent data =new ShareDataEnrollStudent();
						data.setData(enroll);
						System.out.println(enroll);
						Student_Home obj=new Student_Home();
						obj.setVisible(true);
						Student_Login.this.setVisible(false);
					}
					
				}
				catch(Exception e)
				{}
			}
				});
		
		
		
	}
}
