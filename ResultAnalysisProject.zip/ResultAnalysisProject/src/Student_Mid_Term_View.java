import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import java.awt.Color;

public class Student_Mid_Term_View extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Mid_Term_View frame = new Student_Mid_Term_View();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Mid_Term_View() {
		setTitle("View Result");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 564, 656);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("G:\\java programs\\ResultAnalysisProject\\images\\pd.jpg"));
		lblNewLabel.setBounds(68, 92, 137, 165);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ENROLL");
		lblNewLabel_1.setBounds(273, 92, 82, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("NAME");
		lblNewLabel_2.setBounds(273, 133, 82, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("BRANCH");
		lblNewLabel_3.setBounds(273, 178, 82, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("SEMESTER");
		lblNewLabel_4.setBounds(273, 225, 95, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(397, 92, 141, 14);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBounds(397, 133, 141, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setBounds(397, 178, 141, 14);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setBounds(397, 225, 141, 14);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("DBMS");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_9.setBounds(68, 308, 46, 14);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("COMPUTER ARCHITECTURE");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_10.setBounds(68, 353, 182, 14);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("TELECOMMUNICATION FUNDAMENTALS");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_11.setBounds(68, 392, 236, 14);
		contentPane.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("ECOMMERCE");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_12.setBounds(68, 438, 192, 14);
		contentPane.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("OPERATING SYSTEMS");
		lblNewLabel_13.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_13.setBounds(68, 483, 192, 14);
		contentPane.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("DIGITAL SIGNAL PROCESSING");
		lblNewLabel_14.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_14.setBounds(68, 530, 182, 14);
		contentPane.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("");
		lblNewLabel_15.setBounds(363, 309, 116, 14);
		contentPane.add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("");
		lblNewLabel_16.setBounds(363, 354, 116, 14);
		contentPane.add(lblNewLabel_16);
		
		JLabel lblNewLabel_17 = new JLabel("");
		lblNewLabel_17.setBounds(363, 393, 116, 14);
		contentPane.add(lblNewLabel_17);
		
		JLabel lblNewLabel_18 = new JLabel("");
		lblNewLabel_18.setBounds(363, 439, 116, 14);
		contentPane.add(lblNewLabel_18);
		
		JLabel lblNewLabel_19 = new JLabel("");
		lblNewLabel_19.setBounds(363, 484, 116, 14);
		contentPane.add(lblNewLabel_19);
		
		JLabel lblNewLabel_20 = new JLabel("");
		lblNewLabel_20.setBounds(363, 531, 116, 14);
		contentPane.add(lblNewLabel_20);
		
		JButton btnNewButton = new JButton("BACK ");
		btnNewButton.setBounds(68, 583, 192, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("LOG OUT");
		btnNewButton_1.setBounds(289, 583, 190, 23);
		contentPane.add(btnNewButton_1);
		
		ShareDataEnrollStudent data=new ShareDataEnrollStudent();
		String enroll=data.getData();
		connector con=new connector();
		try{
			
			PreparedStatement ps1=connector.con1.prepareStatement("select * from 5_sem_it_mtt1");
			
			ResultSet rs1=ps1.executeQuery();
			
			try{
				PreparedStatement ps=connector.con1.prepareStatement("select * from student_info");
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					System.out.println("1");
					String enrollchk=rs.getString("enroll");
					System.out.println(enrollchk);
					System.out.println(enroll);
					String name=rs.getString("name");
					String semester=rs.getString("semester");
					String branch=rs.getString("branch");
					if(enrollchk.equals(enroll))
					{
						System.out.println("2");
						lblNewLabel_5.setText(enroll);
						lblNewLabel_6.setText(name);
						lblNewLabel_7.setText(branch);
						lblNewLabel_8.setText(semester);
					}
				}}catch(Exception e)
			{}
			while(rs1.next())
			{
				String dbms=rs1.getString("dbms");
				String ca=rs1.getString("ca");
				String tef=rs1.getString("tef");
				String ecomm=rs1.getString("ecomm");
				String os=rs1.getString("os");
				String dsp=rs1.getString("dsp");
				String enrollchk=rs1.getString("enroll");
			
				if(enrollchk.equals(enroll))
						{
							lblNewLabel_15.setText(dbms);
							lblNewLabel_16.setText(ca);
							lblNewLabel_17.setText(tef);
							lblNewLabel_18.setText(ecomm);
							lblNewLabel_19.setText(os);
							lblNewLabel_20.setText(dsp);
						}
			}
			
		}catch(Exception e)
		{
			
		}
		//Log out button
		btnNewButton_1.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Student_Home obj=new Student_Home();
				obj.setVisible(true);
				Student_Mid_Term_View.this.setVisible(false);
			}
				});
		//back button
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Student_Mid_Term obj=new Student_Mid_Term();
				obj.setVisible(true);
				Student_Mid_Term_View.this.setVisible(false);
			}
				});
	}

}
