
public class ShareDataEnroll {
static String enroll="null value";
	public  void setData(String enr)
	{
	ShareDataEnroll.enroll=enr;
	}
	public  String getData()
	{
		return enroll;
	}
}