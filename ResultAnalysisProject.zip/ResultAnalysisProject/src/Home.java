import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

public class Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setTitle("Home Page");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 542, 444);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("It's Hard to beat a Person who NEVER GIVES UP");
		lblNewLabel.setBounds(29, 27, 447, 28);
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.PLAIN, 18));
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(43, 61, 313, 242);
		lblNewLabel_1.setIcon(new ImageIcon("G:\\java programs\\ResultAnalysisProject\\images\\jecrc.png"));
		
		JButton btnNewButton = new JButton("Login as Student");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(43, 340, 138, 60);
		
		JButton btnNewButton_1 = new JButton("Login as Admin");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton_1.setBounds(306, 340, 138, 60);
		
		
		//Student button
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae){
				
				Student_Login obj=new Student_Login();
				obj.setVisible(true);
				Home.this.setVisible(false);
				
			}
				});
		
		
		//aDMIN bUTOTN
		btnNewButton_1.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae){
				Admin_Login obj=new Admin_Login();
				obj.setVisible(true);
				Home.this.setVisible(false);
			}
				});
		
		
		
		
		
		
		
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(lblNewLabel_1);
		contentPane.add(btnNewButton_1);
		contentPane.add(btnNewButton);
	}

}
