import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class AdminHome extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminHome frame = new AdminHome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminHome() {
		setTitle("Admin Home");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 645, 567);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("ADD RESULT");
		btnNewButton.setBounds(38, 341, 141, 56);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ADD STUDENT");
		btnNewButton_1.setBounds(246, 341, 141, 56);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("UPDATE STUDENT");
		btnNewButton_2.setBounds(444, 341, 141, 56);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("ADD ADMIN");
		btnNewButton_3.setBounds(38, 449, 141, 56);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("UPDATE ADMIN");
		btnNewButton_4.setBounds(246, 449, 141, 56);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("LOG OUT");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton_5.setBounds(444, 449, 141, 56);
		contentPane.add(btnNewButton_5);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("G:\\java programs\\ResultAnalysisProject\\images\\20160909123538.png"));
		lblNewLabel.setBounds(137, 23, 448, 269);
		contentPane.add(lblNewLabel);
		
		
		//LOG OUT BUTTON
		btnNewButton_5.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Admin_Login obj=new Admin_Login();
				obj.setVisible(true);
				AdminHome.this.setVisible(false);
			}
				});
		
		//Add REsult 
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Add_Result obj=new Add_Result();
				obj.setVisible(true);
				AdminHome.this.setVisible(false);
				
			}
				});
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
