import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class Student_Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Home frame = new Student_Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Home() {
		setTitle("Student Home");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 523, 662);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("G:\\java programs\\ResultAnalysisProject\\images\\20160909123633.jpg"));
		lblNewLabel.setBounds(94, 71, 302, 368);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Education is the most Powerful Weapon");
		lblNewLabel_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(88, 27, 397, 33);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Mid Term");
		btnNewButton.setFont(new Font("Bookman Old Style", Font.PLAIN, 11));
		btnNewButton.setBounds(62, 488, 132, 41);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Unit Test");
		btnNewButton_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 11));
		btnNewButton_1.setBounds(279, 488, 132, 41);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("LOG OUT");
		btnNewButton_2.setFont(new Font("Bookman Old Style", Font.PLAIN, 11));
		btnNewButton_2.setBounds(62, 559, 349, 23);
		contentPane.add(btnNewButton_2);
		//lOG oUT bUTTON
		btnNewButton_2.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Student_Login obj=new Student_Login();
				obj.setVisible(true);
				Student_Home.this.setVisible(false);
			}
				});
		
		//Mid Term
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				ShareDataEnrollStudent data=new ShareDataEnrollStudent();
				String enr=data.getData();
				data.setData(enr);
				Student_Mid_Term obj=new Student_Mid_Term();
				obj.setVisible(true);
				Student_Home.this.setVisible(false);
				
			}
				});
	
	}
}
