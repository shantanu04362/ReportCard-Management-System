import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Add_Result_0 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Result_0 frame = new Add_Result_0();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Result_0() {
		setTitle("Select Exam");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 485, 187);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Mid Term");
		btnNewButton.setFont(new Font("Bookman Old Style", Font.PLAIN, 14));
		btnNewButton.setBounds(10, 36, 102, 69);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Unit Test");
		btnNewButton_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 14));
		btnNewButton_1.setBounds(170, 36, 102, 69);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setFont(new Font("Bookman Old Style", Font.PLAIN, 14));
		btnNewButton_2.setBounds(335, 36, 102, 69);
		contentPane.add(btnNewButton_2);
	
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Mid_Term obj=new Mid_Term();
				obj.setVisible(true);
				Add_Result_0.this.setVisible(false);
			}
				});
	
	
	
	}
}
