import java.sql.Connection;
import java.sql.DriverManager;

public class connector {

public static	Connection con1=null;
	static {
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con1=(Connection)DriverManager.getConnection("jdbc:mysql://den1.mysql1.gear.host:3306/resultanalysis","resultanalysis","Xk367-6Kx_9w");
			}catch(Exception e){}
	
	
	}

}
