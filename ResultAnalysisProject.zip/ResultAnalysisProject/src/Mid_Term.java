import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

public class Mid_Term extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mid_Term frame = new Mid_Term();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Mid_Term() {
		setTitle("Mid Terms");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 342, 245);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Mid term 1");
		btnNewButton.setFont(new Font("Bookman Old Style", Font.PLAIN, 11));
		btnNewButton.setBounds(20, 51, 103, 76);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Mid Term 2");
		btnNewButton_1.setFont(new Font("Bookman Old Style", Font.PLAIN, 11));
		btnNewButton_1.setBounds(189, 51, 103, 76);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setFont(new Font("Bookman Old Style", Font.PLAIN, 11));
		btnNewButton_2.setBounds(20, 153, 272, 23);
		contentPane.add(btnNewButton_2);
	
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Add_Result_1 obj=new Add_Result_1();
				obj.setVisible(true);
				Mid_Term.this.setVisible(false);
			}
				});
	
	}

}
