import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

public class Add_Result_1 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_Result_1 frame = new Add_Result_1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add_Result_1() {
		setTitle("ADD RESULT");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 577, 616);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(100, 149, 237));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(22, 36, 155, 175);
		lblNewLabel.setIcon(new ImageIcon("G:\\java programs\\ResultAnalysisProject\\images\\pd.jpg"));
		
		JLabel lblNewLabel_1 = new JLabel("ENROLL");
		lblNewLabel_1.setBounds(214, 72, 75, 14);
		
		JLabel lblNewLabel_2 = new JLabel("NAME");
		lblNewLabel_2.setBounds(214, 104, 46, 14);
		
		JLabel lblNewLabel_3 = new JLabel("BRANCH");
		lblNewLabel_3.setBounds(214, 136, 75, 14);
		
		JLabel lblNewLabel_4 = new JLabel("SEMESTER");
		lblNewLabel_4.setBounds(214, 168, 83, 14);
		
		JLabel lblNewLabel_5 = new JLabel("");
		lblNewLabel_5.setBounds(372, 72, 152, 14);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBounds(372, 104, 152, 14);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setBounds(372, 136, 152, 14);
		
		JLabel lblNewLabel_8 = new JLabel("");
		lblNewLabel_8.setBounds(372, 168, 152, 14);
		
		JLabel lblNewLabel_9 = new JLabel("DBMS");
		lblNewLabel_9.setBounds(52, 270, 65, 17);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textField = new JTextField();
		textField.setBounds(346, 270, 86, 20);
		textField.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("COMPUTER ARCHITECTURE");
		lblNewLabel_10.setBounds(52, 308, 173, 17);
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textField_1 = new JTextField();
		textField_1.setBounds(346, 308, 86, 20);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("TELECOMMUNICATION FUNDAMENTALS");
		lblNewLabel_11.setBounds(52, 349, 245, 17);
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textField_2 = new JTextField();
		textField_2.setBounds(346, 346, 86, 20);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("ECOMMERCE");
		lblNewLabel_12.setBounds(52, 387, 81, 17);
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textField_3 = new JTextField();
		textField_3.setBounds(346, 384, 86, 20);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_13 = new JLabel("OPERATING SYSTEMS");
		lblNewLabel_13.setBounds(52, 425, 135, 17);
		lblNewLabel_13.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textField_4 = new JTextField();
		textField_4.setBounds(346, 422, 86, 20);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_14 = new JLabel("DIGITAL SIGNAL PROCESSING");
		lblNewLabel_14.setBounds(52, 463, 185, 17);
		lblNewLabel_14.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		textField_5 = new JTextField();
		textField_5.setBounds(346, 460, 86, 20);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD RESULT");
		btnNewButton.setBounds(380, 520, 171, 23);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel);
		contentPane.add(lblNewLabel_1);
		contentPane.add(lblNewLabel_2);
		contentPane.add(lblNewLabel_3);
		contentPane.add(lblNewLabel_4);
		contentPane.add(lblNewLabel_5);
		contentPane.add(lblNewLabel_6);
		contentPane.add(lblNewLabel_7);
		contentPane.add(lblNewLabel_8);
		contentPane.add(lblNewLabel_9);
		contentPane.add(textField);
		contentPane.add(lblNewLabel_10);
		contentPane.add(textField_1);
		contentPane.add(lblNewLabel_11);
		contentPane.add(textField_2);
		contentPane.add(lblNewLabel_12);
		contentPane.add(textField_3);
		contentPane.add(lblNewLabel_13);
		contentPane.add(textField_4);
		contentPane.add(lblNewLabel_14);
		contentPane.add(textField_5);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.setBounds(10, 520, 167, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_15 = new JLabel("");
		lblNewLabel_15.setBounds(230, 552, 202, 14);
		contentPane.add(lblNewLabel_15);
		
		JButton btnNewButton_2 = new JButton("BACK TO ADMIN HOME");
		btnNewButton_2.setBounds(195, 520, 167, 23);
		contentPane.add(btnNewButton_2);
		

		ShareDataEnroll data=new ShareDataEnroll();
		String enroll=data.getData();
		connector con=new connector();
		try{
			PreparedStatement ps=connector.con1.prepareStatement("select * from student_info");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				String enrollchk=rs.getString("enroll");
				String name=rs.getString("name");
				String semester=rs.getString("semester");
				String branch=rs.getString("branch");
				if(enrollchk.equals(enroll))
				{
					lblNewLabel_5.setText(enroll);
					lblNewLabel_6.setText(name);
					lblNewLabel_7.setText(branch);
					lblNewLabel_8.setText(semester);
				}
			}
		}catch(Exception e){}
		
		
		//BACK BUTTON
		btnNewButton_1.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				Add_Result obj=new Add_Result();
				obj.setVisible(true);
				Add_Result_1.this.setVisible(false);
			}
				});
		
		//BACK TO ADMIN HOME
		btnNewButton_2.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				AdminHome obj=new AdminHome();
				obj.setVisible(true);
				Add_Result_1.this.setVisible(false);
			}
				});
		
		//ADD RESULT BUTTON
		btnNewButton.addActionListener(new ActionListener()
				{
			public void actionPerformed(ActionEvent ae)
			{
				ShareDataEnroll data=new ShareDataEnroll();
				int i=0;
				String enroll=data.getData();
				String dbms=textField.getText();
				String ca=textField_1.getText();
				String tef=textField_2.getText();
				String ecomm=textField_3.getText();
				String os=textField_4.getText();
				String dsp=textField_5.getText();
				connector con=new connector();
				try{
					PreparedStatement ps=connector.con1.prepareStatement("insert into 5_sem_it_mtt1 values(?,?,?,?,?,?,?)");
					ps.setString(1, enroll);
					ps.setString(2,dbms);
					ps.setString(3,ca);
					ps.setString(4, tef);
					ps.setString(5, ecomm);
					ps.setString(6, os);
					ps.setString(7, dsp);
					i=ps.executeUpdate();
				}catch(Exception e){}
				
				if(i==0)
				{
					lblNewLabel_15.setForeground(Color.red);
					lblNewLabel_15.setText("result not added");
				}
				else
				{
					lblNewLabel_15.setForeground(Color.GREEN);
					lblNewLabel_15.setText("Result Added");
				}
			}
				});
		
		
	}

}
